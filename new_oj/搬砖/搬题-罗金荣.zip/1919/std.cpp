#include<stdio.h>
#include<stdlib.h>

int main()
{
	char a;
	scanf("%c",&a);
	printf("%c\n",a+32);
	return 0;
}
