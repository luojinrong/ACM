#include<stdio.h>

int main(int argc, char* argv[])
{printf("0.097656,299.902344");
	return 0;
}