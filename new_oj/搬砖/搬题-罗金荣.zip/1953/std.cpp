#include<stdio.h>
int main(){
	printf("7744"); 
	return 0;
}
